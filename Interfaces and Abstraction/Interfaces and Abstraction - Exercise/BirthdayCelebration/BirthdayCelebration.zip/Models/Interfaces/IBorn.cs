﻿namespace BirthdayCelebration.Models.Interfaces
{
    public interface IBorn
    {
        public string Date { get; }
    }
}
