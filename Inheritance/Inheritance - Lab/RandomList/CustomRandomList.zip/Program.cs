﻿// Create a RandomList class that has all the functionality of List<string>.
// Add an additional function that returns and removes a random element from the list.
// •	Public method: RandomString(): string

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
        
        }
    }
}
