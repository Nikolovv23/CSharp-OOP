﻿// Create a class StackOfStrings that extends Stack, can store only strings, and has the following functionality:
// •	Public method: IsEmpty(): bool
// •	Public method: AddRange(): Stack<string>

namespace CustomStack
{
    public class StartUp
    {
        static void Main(string[] args)
        {
         
        }
    }
}
