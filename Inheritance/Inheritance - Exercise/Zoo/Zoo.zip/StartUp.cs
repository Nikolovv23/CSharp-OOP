﻿// Create a project Zoo.It needs to contain the following classes:

//                                1.Animal 
//               1.2.Reptile                    1.2.Mammal
//         1.2.3.Lizard  1.2.3.Snake     1.2.3.Gorilla  1.2.3.Bear

// Follow the diagram and create all of the classes. Each of them, except the Animal class, should inherit from another class.
// Every class should have:
// •	A constructor, which accepts one parameter: name.
// •	Property Name - string.


namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}