﻿// Your task is to create the following game hierarchy: 

//  ------ Look at the image in the Diagram folfer ------

// Create a class Hero. It should contain the following members:
// •	A constructor, which accepts:
// o username – string
// o	level – int
// •	The following properties:
// o Username - string
// o	Level – int
// •	ToString() method

namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}